#include <stdio.h>
#include <stdlib.h>
#include "SIGA.h"

int main() {
    Aluno *alunos = NULL;
    int qtdAlunosCadastrados = 0;
    int opcao, matrB, iAluno;
    do {
        printf("               MENU DE ESCOLHAS DO SIGazinho\n\n\n");
        printf("1....Cadastrar um aluno\n");
        printf("2....Procurar um aluno\n");
        printf("3....Remover um aluno\n");
        printf("4....Lista melhores alunos\n");
        printf("5....Lista alunos cadastrados\n");
        printf("6....Sair do sistema\n");
        printf("\n\n\nOpcao: ");
        scanf("%d", &opcao);
        switch(opcao) {
            case 1: alunos = cadastraAluno(alunos, &qtdAlunosCadastrados); break;
            case 2:
                printf("Digite a matricula: ");
                scanf("%d", &matrB);
                iAluno = procuraAluno(alunos, qtdAlunosCadastrados, matrB);
                if(iAluno!=-1) // Encontrei
                    printAluno(alunos[iAluno]);
                else printf("Esta matricula nao esta cadastrada\n");
                break;
            case 3: alunos = removeAluno(alunos, &qtdAlunosCadastrados); break;
            case 4: listaMelhores(alunos, qtdAlunosCadastrados); break;
            case 5: listaAlunos(alunos, qtdAlunosCadastrados); break;
            case 6: break;
            default: printf("Preste atencao!!! Opcao invalida\n");
        }
    } while(opcao!=6);
    printf("Tchau. Um abraco. Valeu por me usar!\n");
    if(alunos!=NULL) free(alunos);
    return 0;
}
