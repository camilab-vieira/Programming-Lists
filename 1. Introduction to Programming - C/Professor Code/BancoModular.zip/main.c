#include <stdio.h>
#include <stdlib.h>
#include "Banco.h"

int main() {
    Banco *agenciaCidade, *agenciaUFPE;
    agenciaCidade = newBanco(123, 1000);
    if(agenciaCidade!=NULL)
        insereConta(agenciaCidade, 555, 1500.5);
    agenciaUFPE = newBanco(333, 100);
    return 0;
}
