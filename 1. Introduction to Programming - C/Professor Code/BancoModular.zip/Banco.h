#include "Agencia.h"
typedef struct { // class = struct + funcoes
    int agencia, totContas, qtdContas;// qtdContas <= totContas
    Conta **contas;
} Banco;

Banco *newBanco(int agencia, int totContas) {
    Banco *bTmp = (Banco *) malloc(sizeof(Banco));
    if(bTmp==NULL) exit(1);
    bTmp -> contas = (Conta **) malloc(totContas * sizeof(Conta *));
    if(bTmp -> contas==NULL) exit(1);
    bTmp -> totContas = totContas;
    bTmp -> agencia = agencia;
    return bTmp;
}

void insereConta(Banco *banco, int conta, float saldo) {
    int i, encontrei = 0;
    for(i=0; i < banco -> qtdContas && !encontrei; i++)
        if((banco -> contas[i]) -> contaCC == conta) {
            encontrei = 1;
        }
    if(!encontrei) {
        if(banco -> qtdContas < banco -> totContas) {
            Conta *cTmp = newConta(conta, saldo);
            (banco -> contas[(banco -> qtdContas)+1]) = cTmp;
            (banco -> qtdContas)++;
        }
        else printf("Agencia nao suporta contas em excesso\n");
    } else printf("Conta ja existe nesta agencia\n");
}
