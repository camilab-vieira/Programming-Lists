typedef struct {
    char nome[50];
    int matricula;
    float nota;
} Aluno;

void printAluno(Aluno aluno) {
    printf("Nome: %s\n", aluno.nome);
    printf("Matricula: %d\n", aluno.matricula);
    printf("Nota: %.1f\n", aluno.nota);
}
int procuraAluno(Aluno *alunos, int qtdAlunosCadastrados, int matrB) {
    int encontrei = -1; // Nao encontrei
    if(alunos!=NULL) {
        for(int i=0; i<qtdAlunosCadastrados && encontrei==-1; i++)
            if(alunos[i].matricula==matrB) encontrei = i;
    }
    else printf("Sem alunos cadastrados\n");
    return encontrei;
}

Aluno *cadastraAluno(Aluno *alunos, int *qtdAlunosCadastrados) {
    Aluno alunoT;
    printf("Qual seu nome? ");
    scanf(" %49[^\n]", alunoT.nome);
    printf("Matricula: ");
    scanf("%d", &alunoT.matricula);
    printf("Nota: ");
    scanf("%f", &alunoT.nota);
    if(procuraAluno(alunos, *qtdAlunosCadastrados, alunoT.matricula)==-1) {
        alunos = (Aluno *) realloc(alunos, ((*qtdAlunosCadastrados)+1) * sizeof(Aluno));
        if(alunos==NULL) {
            printf("Problema de alocacao\n"); exit(1);
        }
        alunos[*qtdAlunosCadastrados] = alunoT;
        (*qtdAlunosCadastrados)++;
        printf("Cadastro realizado com sucesso\n");
    }
    else printf("Matricula existente\n");
    return alunos;
}
Aluno *removeAluno(Aluno *alunos, int *qtdAlunosCadastrados) {
    int matrB, iAluno;
    if(alunos!=NULL) {
        printf("Qual a matricula a remover: ");
        scanf("%d", &matrB);
        if((iAluno=procuraAluno(alunos, *qtdAlunosCadastrados, matrB))!=-1) {
            alunos[iAluno] = alunos[(*qtdAlunosCadastrados)-1];
            (*qtdAlunosCadastrados)--;
            alunos = (Aluno *) realloc(alunos, (*qtdAlunosCadastrados) * sizeof(Aluno));
            if(*qtdAlunosCadastrados==0)
                alunos = NULL;
        }
        else printf("Matricula nao encontrada\n");
    }
    else printf("Sem alunos cadastrados\n");
    return alunos;
}
float mediaVet(Aluno *alunos, int qtdAlunosCadastrados) {
    float soma = 0;
    int i;
    if(alunos!=NULL) {
        for(i=0; i<qtdAlunosCadastrados; i++)
            soma += alunos[i].nota;
        return soma / qtdAlunosCadastrados;
    }
    else printf("Sem alunos cadastrados\n");
    return -1;
}
void listaMelhores(Aluno *alunos, int qtdAlunosCadastrados) {
    if(alunos!=NULL) {
        float media = mediaVet(alunos, qtdAlunosCadastrados);
        for(int i=0; i<qtdAlunosCadastrados; i++)
            if(alunos[i].nota>=media) printAluno(alunos[i]);
    }
    else
        printf("Nao ha alunos cadastrados\n");
}
void listaAlunos(Aluno *alunos, int qtdAlunosCadastrados) {
    int i;
    if(alunos!=NULL)
        for(i=0; i<qtdAlunosCadastrados; i++) printAluno(alunos[i]);
    else printf("Sem alunos cadastrados\n");
}
