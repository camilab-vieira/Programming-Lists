typedef struct { // class = struct + funcoes
    int contaCC;
    float saldo;
} Conta;

Conta *newConta(int conta, float saldo) {
    Conta *cTmp = (Conta *) malloc(sizeof(Conta));
    if(cTmp==NULL) exit(1);
    cTmp -> contaCC = conta;
    cTmp -> saldo = saldo;
    return cTmp;
}
